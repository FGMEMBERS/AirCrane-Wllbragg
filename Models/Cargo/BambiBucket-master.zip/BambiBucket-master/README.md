# BambiBucket
BambiBucket 910 liter model made by Martien van der Plas for FlightGear
